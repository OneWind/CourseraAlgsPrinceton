public class Subset {
    public static void main(String[] args) {
        int k = Integer.parseInt(args[0]);
        RandomizedQueue<String> q = new RandomizedQueue<String>();
        int i = 0;
        double tmp;
        int pos;
        while (!StdIn.isEmpty()) {
            String item = StdIn.readString();
            if (i < k) {
                q.enqueue(item);
            } else {
                tmp = StdRandom.random();
                if (tmp < (float)i/(i+1)) {
                    pos = StdRandom.uniform(i);
                    q.enqueue(item);
                }
            }
            i++;
        }
        for (int j = 0; j < k; j++) {
            System.out.println(q.dequeue());
        }
        
    }
}